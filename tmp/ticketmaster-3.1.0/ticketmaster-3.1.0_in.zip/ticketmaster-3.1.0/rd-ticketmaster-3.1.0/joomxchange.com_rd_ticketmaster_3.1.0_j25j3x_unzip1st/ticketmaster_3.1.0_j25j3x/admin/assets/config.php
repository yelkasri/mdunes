<?php

## no direct access
defined('_JEXEC') or die('Restricted access');


?>

<div id="submenu-box">
    <div class="t">
        <div class="t">
            <div class="t">
            </div>
        </div>
     </div>
    <div class="m">
        <ul id="submenu">
            <li>
            <a href="index.php?option=com_ticketmaster">
				<?php echo JText::_( 'COM_TICKETMASTER_CPANEL' ); ?></a>
            </li>
            <li>
            <a href="index.php?option=com_ticketmaster&controller=configuration">
				<?php echo JText::_( 'COM_TICKETMASTER_CONFIG' ); ?></a>
            </li>
            <li>
            <a href="index.php?option=com_ticketmaster&controller=mail">
				<?php echo JText::_( 'COM_TICKETMASTER_EMAILCONFIG' ); ?></a>
            </li>
                                   
            </ul>
        <div class="clr">
    </div>
    </div>
        <div class="b">
            <div class="b">
                <div class="b"></div>
            </div>
        </div>
    </div>
   
