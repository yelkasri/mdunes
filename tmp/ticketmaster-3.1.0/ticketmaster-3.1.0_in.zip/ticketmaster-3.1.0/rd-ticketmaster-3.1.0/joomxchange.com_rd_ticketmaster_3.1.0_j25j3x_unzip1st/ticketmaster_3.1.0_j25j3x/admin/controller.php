<?php
/****************************************************************
 * @version			Ticketmaster 2.5.5							
 * @package			ticketmaster									
 * @copyright		Copyright © 2009 - All rights reserved.			
 * @license			GNU/GPL											
 * @author			Robert Dam										
 * @author mail		info@rd-media.org								
 * @website			http://www.rd-media.org							
 ***************************************************************/

## no direct access
defined('_JEXEC') or die('Restricted access');

jimport('joomla.application.component.controller');

class ticketmasterController extends JControllerLegacy
{
	/**
	 * Custom Constructor
	 */

	function __construct()
	{
		parent::__construct();
	}




}
?>