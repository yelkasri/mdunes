ALTER TABLE `#__ticketmaster_clients` ADD `ipaddress` VARCHAR( 60 ) NOT NULL;
ALTER TABLE `#__ticketmaster_orders` ADD `ipaddress` VARCHAR( 60 ) NOT NULL;
