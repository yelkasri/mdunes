<?php
defined ('_JEXEC') or die ('Restricted Acces - No Access');


class TableMail extends JTable {

	function __construct(&$db) {
		parent::__construct( '#__ticketmaster_emails' , 'emailid' , $db );
	}	
}
?>