<?php 
/**
 * @version		1.0.0 ticketmaster $
 * @package		ticketmaster
 * @copyright	Copyright � 2009 - All rights reserved.
 * @license		GNU/GPL
 * @author		Robert Dam
 * @author mail	info@rd-media.org
 * @website		http://www.rd-media.org
 */

## Check if the file is included in the Joomla Framework
defined('_JEXEC') or die ('No Acces to this file!');

?>

<h2 class="contentheading">
	<?php echo JText::_('COM_TICKETMASTER_VALIDATION_OK'); ?>
</h2>

<?php echo JText::_('COM_TICKETMASTER_VALIDATION_OK_DESC'); ?><br /><br /><br />


